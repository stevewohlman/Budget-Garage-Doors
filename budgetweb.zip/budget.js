

function btnsloganevent {
	btnslogan.onmouseover ;

}

function btnsloganevent {

	btnslogan.onmouseout ;
}
